### Maintenance-Jeu

# Airplan War, un jeu de combat aérien entièrement codé sous python !

Dans ce jeu, affrontez une horde de vaisseaux ennemis qui foncent vers vous pour vous arrêter !
Défendez vous grâce à votre armement en appuyant sur la barre espace, et esquivez la menace en utilisant les flèches directionnelles ou avec WASD.

# Lancer le jeu
Pour lancer le jeu, simplement décompressez le fichier zip dans le dossier de votre choix et exécutez le fichier principal Airplan_War.py.

 - Commande linux :

	    python3 Airplan_War.py
